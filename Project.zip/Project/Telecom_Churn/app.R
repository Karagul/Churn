#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

# Define UI for application that draws a histogram
ui <- shinyUI(fluidPage(
  useShinyjs(),
  includeCSS("www/bootstrap.min.css"),
  ##theme = shinytheme("Spacelab"),
  titlePanel("Customer Churn Prediction"),
  title = "Telecom Customer Churn Prediction",
  p(em("Help:", a("How to use this App", href="README.html"))),
  
  tabsetPanel(
    id = "navbar",
    tabPanel("Customer Info",
             tags$head(
               tags$style(type='text/css',".nav-tabs {font-size: 20px} ")), 
             sidebarLayout(sidebarPanel(
               tags$style(type='text/css',".nav-tabs {font-size: 20px} "),
               checkboxInput("showTrainingData", "Show Training Dataset", TRUE),
               checkboxInput("showvis", "Show Chart", TRUE),
               fileInput("file1", "Choose a CSV file to import:",
                         accept = c("text/csv", "text/comma-separated-values, text/plain", ".csv")),
               selectInput("Algo", "Model:",
                           list("Decision Tree" ="DT",
                                ##"Lasso Regression" = "LR",
                                "Logistic Regression" = "LogisticR",
                                "Naive Bayes" = "NaiveB",
                                # Small data so should not use Neural Network
                                # "Neural Network" = "NN",
                                "Random Forest" = "RandomF",
                                "Recurssive Partition" = "RP",
                                "Support Vector Machine"="SVM")),
               actionButton("submit", "Submit",style="color: #fff; background-color: #df691a; border-color: #df691a"),##,
               actionButton("reset", "Reset Predictions Data",style="color: #fff; background-color: #df691a; border-color: #df691a"),##,
               ### Display training link 
               ## actionLink("Training Set","Show Training Set",icon = icon("table"))
               p(em("Sample file can be downloaded from:", downloadLink("Sam", "Sample.csv")))
               
               
             ),
             mainPanel(
               tags$hr(),
               h4("Customers Account Information"),
               dataTableOutput("content"),
               tags$hr(),
               wellPanel(p(actionButton("pred", "Predict",style="color: #fff; background-color: #df691a; border-color: #df691a"), downloadButton("dnld", "Download"))),
               h4("Result of Prediction (Potentially churn list):"),
               textOutput("no.churn.data"),
               dataTableOutput("result")
             )
             )),
    tabPanel( title = "Training Dataset",value = "tab2",
              h1("Training set for Model")
              ,tags$head(
                tags$style(type='text/css',".nav-tabs {font-size: 20px} ")),
              mainPanel(
              dataTableOutput("trainingset")
              )),
    tabPanel( title = "Visualisation of the Dataset",value = "tab3",
              h1("Chart for Churn")
              ,tags$head(
                tags$style(type='text/css',".nav-tabs {font-size: 20px} ")),
              mainPanel(
                plotlyOutput("pplot")  
              ))
    
  ))
)



# Define server logic required to draw a histogram
server <- # load the trained final predictive model.
  shinyServer(function(input, output) {

    
  ##### On check/uncheck display/hide the Training Tab  
    observe({
      toggle(condition = input$showTrainingData, selector = "#navbar li a[data-value=tab2]" )
    })
  
    ##### On check/uncheck display/hide the Chart Tab  
    observe({
      toggle(condition = input$showvis, selector = "#navbar li a[data-value=tab3]")
    })
    
    
######Code for upload file commands     
    
    selectFileMsg <- "Please Select a CSV file to upload"
    ##### retrieving the customer information through the uploaded csv file.
    ##### Event Reactive to display the data  once the submit button is ticked
    data.upload.file <- eventReactive(input$submit, {inFile <- input$file1
    if (is.null(inFile)) renderText(selectFileMsg)
    else read.csv(inFile$datapath)})
    
    
    # display the data from the csv file.
    output$content <- renderDataTable(data.upload.file(), options = list(iDisplayLength = 10))
    
    
#### Code for running the prediction models
    
    # predicting the churn using the ML model for the displayed customer accounts.
    churn.predict.Result <- eventReactive(input$pred,
                                          {isolate({
                                            ##counter_resetbtn <- counter_resetbtn + 1
                                            data.uploaded <- data.upload.file()
                                            if (!is.null(data.uploaded)) {
                                              ###### Logistic Regression model
                                              if (input$Algo=='LogisticR') {
                                                #ifelse(any(ls() %in% "data.lr"), rm(data.lr),TRUE)
                                                data.lr <- data.uploaded
                                                train.data.set <- read.csv ("data/LogR_OutputPred.csv")
                                                independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                
                                                independent.testset <- data.lr[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                
                                                train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                logR.model <- glm(train.dataframe$response~.,family = binomial, data=train.dataframe)
                                                pred <- predict(logR.model,newdata=data.frame(independent.testset),type="response")
                                                data.lr$pred.churn = ifelse( pred>=0.5,"Yes","No")
                                                data.output <-  subset(data.lr, pred.churn=="Yes")
                                              } 
                                              ###### SVM model
                                              else if (input$Algo=='SVM') {
                                                #ifelse(any(ls() %in% "data.svm"), rm(data.svm),TRUE)
                                                data.svm <- data.uploaded
                                                train.data.set<- read.csv ("data/SVM_OutputPred.csv")
                                                independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                
                                                independent.testset <- data.svm [,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                
                                                train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                svm.model <-    svm(train.dataframe$response ~., data = train.dataframe,kernel = "radial", gamma = .99,cost = 50)
                                                pred <- predict(svm.model, independent.testset)
                                                pred <- as.matrix(pred)
                                                data.svm$pred.churn <- ifelse(pred>=0.5,"Yes","No")
                                                data.output <-  subset(data.svm, pred.churn=="Yes")
                                              }
                                              #else if (input$Algo=='NN') {
                                              #ifelse(any(ls() %in% "data.nn"), rm(data.nn),TRUE)
                                              # data.nn <- data.uploaded
                                              # train.data.set<- read.csv ("data/NN_OutputPred.csv")
                                              # independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                              # independent.testset <- data.nn[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                              # # dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                              # train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                              # nn.model <- neuralnet(train.dataframe$response ~VMail.Message+Day.Mins+Eve.Mins+Night.Mins+Intl.Mins+CustServ.Calls+Int.l.Plan+VMail.Plan+Day.Charge+Eve.Charge+Night.Charge+Intl.Calls+Intl.Charge , data =train.dataframe, hidden = 2, err.fct = "ce", linear.output = FALSE)
                                              # pred.neural.dataset <- compute(nn.model, independent.testset, rep = 1)$net.result
                                              # data.nn$pred.churn = ifelse(pred.neural.dataset>=0.5,"Yes","No")
                                              # data.output <-  subset(data.nn, pred.churn=="Yes")
                                              # }
                                              #else if (input$Algo=='LR') {
                                                #ifelse(any(ls() %in% "data.lar"), rm(data.lar),TRUE)
                                               # data.lar <- data.uploaded
                                                #train.data.set <- read.csv ("data/LaR_OutputPred.csv")
                                                #independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                #independent.trainset <- as.matrix(independent.trainset)
                                                #independent.testset <- data.lar[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                #dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                #dependent.trainset <- as.matrix(dependent.trainset)
                                                #train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                #CV = cv.glmnet(x = independent.trainset, y= dependent.trainset, family ="binomial", type.measure = 'mse',nfolds=5,alpha=.5)
                                                #fit = glmnet(x = independent.trainset, y = dependent.trainset, family = "binomial", lambda = CV$lambda.1se)
                                                #independent.test.data <- as.matrix(independent.testset)
                                                #Predict_lasso = predict(fit, independent.test.data, type = "response")
                                                #data.lar$pred.churn = ifelse(Predict_lasso[,1]>0.5,"Yes","No")
                                                #data.output <-  subset(data.lar, pred.churn=="Yes")
                                              #}
                                              else if (input$Algo=='DT') {
                                                #ifelse(any(ls() %in% "data.dt"), rm(data.dt),TRUE)
                                                data.dt <- data.uploaded
                                                train.data.set <- read.csv ("data/DT_OutputPred.csv")
                                                independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                ##names(ntrain)
                                                independent.testset <- data.dt[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                ##names(ptrain)
                                                train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                
                                                dt.model <- tree(train.dataframe$response~., data = train.dataframe)
                                                independent.testset1 <- as.data.frame(independent.testset)
                                                pred <- predict( dt.model, independent.testset1)
                                                data.dt$pred.churn = ifelse( pred>0.5,"Yes","No")
                                                data.output <-  subset(data.dt, pred.churn=="Yes")
                                              }
                                              else if (input$Algo=='RP') {
                                                #ifelse(any(ls() %in% "data.rp"), rm(data.rp),TRUE)
                                                data.rp <- data.uploaded
                                                train.data.set <- read.csv ("data/RPart_OutputPred.csv")
                                                independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                ##names(ntrain)
                                                independent.testset <- data.rp[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                ##names(ptrain)
                                                train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                rp.model <- rpart(train.dataframe$response~., data = train.dataframe)
                                                independent.testset2 <- as.data.frame(independent.testset)
                                                pred <- predict( rp.model, independent.testset2)
                                                data.rp$pred.churn = ifelse( pred>=0.5,"Yes","No")
                                                data.output <-  subset(data.rp, pred.churn=="Yes")
                                              }
                                              else if (input$Algo=='RandomF') {
                                                #ifelse(any(ls() %in% "data.rf"), rm(data.rf),TRUE)
                                                data.rf <- data.uploaded
                                                train.data.set <- read.csv ("data/RandomF_OutputPred.csv")
                                                independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                ##names(ntrain)
                                                independent.testset <- data.rf[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                ##names(ptrain)
                                                train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                rf.model <- randomForest(train.dataframe$response~., data = train.dataframe, ntree = 1000)
                                                independent.testset3 <-as.data.frame(independent.testset)
                                                pred <- predict( rf.model, independent.testset3)
                                                data.rf$pred.churn = ifelse( pred>=0.5,"Yes","No")
                                                data.output <-  subset(data.rf, pred.churn=="Yes")
                                              }
                                              else if (input$Algo=='NaiveB') {
                                                #ifelse(any(ls() %in% "data.nb"), rm(data.nb),TRUE)
                                                data.nb <- data.uploaded
                                                train.data.set<- read.csv ("data/NaiveB_OutputPred.csv")
                                                independent.trainset <- train.data.set[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                ##names(ntrain)
                                                independent.testset <- data.nb[,c(3,4,5,6,7,8,9,10,12,14,16,17,18)]
                                                dependent.trainset <- ifelse(train.data.set[,20]=="Yes",1,0)
                                                ##names(ptrain)
                                                train.dataframe <- data.frame(response=dependent.trainset,independent.trainset)
                                                naiveB.model <- naiveBayes(train.dataframe$response ~., data = train.dataframe)
                                                pred <- predict( naiveB.model, independent.testset, type = "raw")
                                                data.nb$pred.churn <- ifelse( pred[,1]>pred[,2],"No","Yes")
                                                data.output <-  subset(data.nb, pred.churn=="Yes")
                                              }
                                              else return()
                                            } else return()
                                            
                                          })
                                            
                                            
                                          })
    
    
    
    # display the predicted accounts which have potential churn probabilities.
    output$no.churn.data <- renderText({
      if (is.null(churn.predict.Result())) "No potentially churn customers in this list!"
    })
    
    
    
##### Code for displaying the Output only when Precit button is clicked
    observe({
      if (input$pred == 0)
        return()
      isolate({
        output$result <- renderDataTable(churn.predict.Result(), options = list(iDisplayLength = 10))
      })
    })
    
##### Reset button command
    observe({
      if (input$reset == 0)
        return()
      isolate({
        output$result <- renderText({"Reset Successful"
        })
      })
    })
    

##### Code for download of predicted records
    # download the predicted results
    output$dnld <- downloadHandler(filename = function(){ paste('churndataset', '.csv', sep='') }, 
                                   content = function(file) {
                                     write.csv(churn.predict.Result(), file)})
    
##### Code for Sample file download    
    sample.file <- reactive({
      x <- read.csv("data/SampleFile.csv")
    })
    
    #output$result <- eventReactive(input$reset,{renderText("Reset Successful", env = parent.frame())})
    
    output$Sam <- downloadHandler(filename = function(){ paste('sample', '.csv', sep='') }, 
                                  content = function(file) {
                                    write.csv(sample.file(), file)})
    
    
    
#### Code to Training dataset on click of the Predict button
    train.disp <- eventReactive(input$pred,
                                {isolate(
                                  {
                                    ###### Logistic Regression model
                                    if (input$Algo=='LogisticR') {
                                      x <- read.csv("data/LogR_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='SVM') {
                                      x <- read.csv("data/SVM_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='NN') {
                                      x <- read.csv("data/NN_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='LR') {
                                      x <- read.csv("data/LaR_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='DT') {
                                      x <- read.csv("data/DT_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='RP') {
                                      x <- read.csv("data/RPart_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='RandomF') {
                                      x <- read.csv("data/RandomF_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else if (input$Algo=='NaiveB') {
                                      x <- read.csv("data/NaiveB_OutputPred.csv")
                                      x <- x[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20)]
                                    }
                                    else return()
                                  })
                                })
    
    
#### Code to display the charts of Training and Test Dataset
    # display the data from the csv file.
    output$trainingset <-renderDataTable(train.disp(), options = list(iDisplayLength = 100))
    ###  renderDataTable(testdata())
    observe({
      if (input$pred == 0)
        return()
      isolate({
      ##### Get the Training Set  
      DataSet1 <- c("Training Set", "Testing Set") 
      trainset <- train.disp()
      trainset_yes <- nrow(subset(trainset, pred.churn=="Yes"))
      trainset_no <- nrow(subset(trainset, pred.churn=="No"))  
        
      testset <- data.upload.file()
      testset_y <- churn.predict.Result()
      testset_yes <- nrow(testset_y)
      testset_no <- nrow(testset) - testset_yes
      data <- data.frame(testset_no, testset_yes)
      
      yesaxis <- c(trainset_yes,testset_yes)
      noaxis <- c(trainset_no,testset_no)
      
      output$pplot <- renderPlotly({ plot_ly(data, x = ~DataSet1, y = ~yesaxis, type = 'bar', name = 'Churn Yes') %>%
      add_trace(y = ~noaxis, name = 'Churn No') %>%
      layout(yaxis = list(title = 'Count of Records'),
             xaxis = list(title = 'Test and Training Dataset'),barmode = 'stack')})
        
    })})
})
shinyApp(ui = ui, server = server)
# Run the application 

