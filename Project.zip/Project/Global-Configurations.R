### This is a Global Settings scripts
## Purpose : A Pre-requisite for setting the Global configurations & libraries 
## before running the Telecom Customer Churn Predictive Analytics Framework

#### Set the working Directory
setwd("F:/Project/Telecom_Churn")

### Maintain a list of Necessary Packages 
list.of.packages <- list("dummies" = "direct",
                         "e1071" = "direct" ,
                         "dplyr" = "direct" ,
                         "shiny" = "direct",
                         "ROCR" ="direct",
                         "pROC"= "direct",
                         "glmnet" = "direct",
                         "tree"="direct",
                         "rpart"="direct",
                         "shinyjs" = "direct",
                         "randomForest" = "direct",
                         "rpart" = "direct",
                         "ggplot2" = "direct",
                         "reshape2" = "direct",
                         "caret" = "direct",
                         "xts" = "direct",
                         "stats" = "direct",
                         "RODBC" = "direct",
                         "ggplot2" = "direct",
                         "ranger"="direct",
                         "Boruta"="direct",
                         "plotly" ="direct",
                         "google/CausalImpact" = "github")

#### Installing Software's
myInstallerfun <- function(key,value) {
  print(paste("Hello!! Please stay Tuned with us while The Package : '",key,"' is Currently Being Installed from '",value,"' ",sep = ""))
  switch(value, 
         "direct" = install.packages(key, dependencies = TRUE),
         "github" = devtools::install_github(key, force = TRUE)
        )
  sapply(key, require, character.only = TRUE)
  }
for(key in names(list.of.packages) ) list.of.packages[key] <- myInstallerfun (key,list.of.packages[[key]])

library(tree)
library(dummies)
library(e1071)
library(dplyr)
library(shiny)
library(ROCR)
library(pROC)
library(glmnet)
library(tree)
library(rpart)
library(shinyjs)
library(randomForest)
library(rpart)
library(caret)
library(xts)
library(stats)
library(RODBC)
library(ranger)
library(Boruta)

library(plotly)






